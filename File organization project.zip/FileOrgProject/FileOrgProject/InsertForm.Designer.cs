﻿namespace FileOrgProject
{
    partial class InsertForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            filenameTxtbox = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            IDtextBox = new TextBox();
            NametextBox = new TextBox();
            TeltextBox = new TextBox();
            YeartextBox = new TextBox();
            GendertextBox = new TextBox();
            label7 = new Label();
            NumOfRecLabel = new Label();
            label9 = new Label();
            FileSizeLabel = new Label();
            SaveBtn = new Button();
            BackBtn = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(24, 48);
            label1.Name = "label1";
            label1.Size = new Size(107, 27);
            label1.TabIndex = 1;
            label1.Text = "File Name";
            // 
            // filenameTxtbox
            // 
            filenameTxtbox.Enabled = false;
            filenameTxtbox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            filenameTxtbox.Location = new Point(150, 45);
            filenameTxtbox.Name = "filenameTxtbox";
            filenameTxtbox.Size = new Size(241, 33);
            filenameTxtbox.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(24, 133);
            label2.Name = "label2";
            label2.Size = new Size(39, 27);
            label2.TabIndex = 3;
            label2.Text = "ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(24, 188);
            label3.Name = "label3";
            label3.Size = new Size(64, 27);
            label3.TabIndex = 4;
            label3.Text = "Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(24, 236);
            label4.Name = "label4";
            label4.Size = new Size(41, 27);
            label4.TabIndex = 5;
            label4.Text = "Tel";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ActiveCaptionText;
            label5.Location = new Point(24, 285);
            label5.Name = "label5";
            label5.Size = new Size(54, 27);
            label5.TabIndex = 6;
            label5.Text = "Year";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(24, 338);
            label6.Name = "label6";
            label6.Size = new Size(76, 27);
            label6.TabIndex = 7;
            label6.Text = "Gender";
            // 
            // IDtextBox
            // 
            IDtextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            IDtextBox.Location = new Point(150, 130);
            IDtextBox.Name = "IDtextBox";
            IDtextBox.Size = new Size(331, 33);
            IDtextBox.TabIndex = 8;
            // 
            // NametextBox
            // 
            NametextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            NametextBox.Location = new Point(150, 185);
            NametextBox.Name = "NametextBox";
            NametextBox.Size = new Size(331, 33);
            NametextBox.TabIndex = 9;
            // 
            // TeltextBox
            // 
            TeltextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            TeltextBox.Location = new Point(150, 233);
            TeltextBox.Name = "TeltextBox";
            TeltextBox.Size = new Size(331, 33);
            TeltextBox.TabIndex = 10;
            // 
            // YeartextBox
            // 
            YeartextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            YeartextBox.Location = new Point(150, 282);
            YeartextBox.Name = "YeartextBox";
            YeartextBox.Size = new Size(331, 33);
            YeartextBox.TabIndex = 11;
            // 
            // GendertextBox
            // 
            GendertextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            GendertextBox.Location = new Point(150, 330);
            GendertextBox.Name = "GendertextBox";
            GendertextBox.Size = new Size(331, 33);
            GendertextBox.TabIndex = 12;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.Location = new Point(512, 41);
            label7.Name = "label7";
            label7.Size = new Size(99, 27);
            label7.TabIndex = 13;
            label7.Text = "#Records";
            // 
            // NumOfRecLabel
            // 
            NumOfRecLabel.AutoSize = true;
            NumOfRecLabel.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            NumOfRecLabel.Location = new Point(634, 41);
            NumOfRecLabel.Name = "NumOfRecLabel";
            NumOfRecLabel.Size = new Size(42, 27);
            NumOfRecLabel.TabIndex = 14;
            NumOfRecLabel.Text = ".....";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label9.Location = new Point(517, 80);
            label9.Name = "label9";
            label9.Size = new Size(94, 27);
            label9.TabIndex = 15;
            label9.Text = "File Size";
            // 
            // FileSizeLabel
            // 
            FileSizeLabel.AutoSize = true;
            FileSizeLabel.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            FileSizeLabel.Location = new Point(634, 80);
            FileSizeLabel.Name = "FileSizeLabel";
            FileSizeLabel.Size = new Size(42, 27);
            FileSizeLabel.TabIndex = 16;
            FileSizeLabel.Text = ".....";
            // 
            // SaveBtn
            // 
            SaveBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            SaveBtn.Location = new Point(460, 407);
            SaveBtn.Name = "SaveBtn";
            SaveBtn.Size = new Size(89, 49);
            SaveBtn.TabIndex = 17;
            SaveBtn.Text = "Save";
            SaveBtn.UseVisualStyleBackColor = true;
            SaveBtn.Click += SaveBtn_Click;
            // 
            // BackBtn
            // 
            BackBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BackBtn.Location = new Point(12, 407);
            BackBtn.Name = "BackBtn";
            BackBtn.Size = new Size(89, 49);
            BackBtn.TabIndex = 18;
            BackBtn.Text = "Back";
            BackBtn.UseVisualStyleBackColor = true;
            BackBtn.Click += BackBtn_Click;
            // 
            // InsertForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.image_from_rawpixel_id_2298455_jpeg_1596869142692;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(686, 474);
            Controls.Add(BackBtn);
            Controls.Add(SaveBtn);
            Controls.Add(FileSizeLabel);
            Controls.Add(label9);
            Controls.Add(NumOfRecLabel);
            Controls.Add(label7);
            Controls.Add(GendertextBox);
            Controls.Add(YeartextBox);
            Controls.Add(TeltextBox);
            Controls.Add(NametextBox);
            Controls.Add(IDtextBox);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(filenameTxtbox);
            Controls.Add(label1);
            Name = "InsertForm";
            Text = "InsertForm";
            Load += InsertForm_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox filenameTxtbox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox IDtextBox;
        private System.Windows.Forms.TextBox NametextBox;
        private System.Windows.Forms.TextBox TeltextBox;
        private System.Windows.Forms.TextBox YeartextBox;
        private System.Windows.Forms.TextBox GendertextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label NumOfRecLabel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label FileSizeLabel;
        private System.Windows.Forms.Button SaveBtn;
        private System.Windows.Forms.Button BackBtn;
    }
}
