﻿namespace FileOrgProject
{
    partial class LoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            loginBtn = new Button();
            backBtn = new Button();
            label1 = new Label();
            label2 = new Label();
            usernameTxtbox = new TextBox();
            passwordTxtbox = new TextBox();
            showpasswordCheckbox = new CheckBox();
            SuspendLayout();
            // 
            // loginBtn
            // 
            loginBtn.BackColor = Color.Honeydew;
            loginBtn.Location = new Point(276, 312);
            loginBtn.Name = "loginBtn";
            loginBtn.Size = new Size(94, 29);
            loginBtn.TabIndex = 0;
            loginBtn.Text = "Log in";
            loginBtn.UseVisualStyleBackColor = false;
            loginBtn.Click += loginBtn_Click;
            // 
            // backBtn
            // 
            backBtn.BackColor = Color.Honeydew;
            backBtn.Location = new Point(12, 370);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(94, 29);
            backBtn.TabIndex = 1;
            backBtn.Text = "Back";
            backBtn.UseVisualStyleBackColor = false;
            backBtn.Click += backBtn_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Location = new Point(12, 100);
            label1.Name = "label1";
            label1.Size = new Size(70, 20);
            label1.TabIndex = 2;
            label1.Text = "Password";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Location = new Point(12, 43);
            label2.Name = "label2";
            label2.Size = new Size(75, 20);
            label2.TabIndex = 3;
            label2.Text = "Username";
            // 
            // usernameTxtbox
            // 
            usernameTxtbox.Location = new Point(93, 43);
            usernameTxtbox.Name = "usernameTxtbox";
            usernameTxtbox.Size = new Size(125, 27);
            usernameTxtbox.TabIndex = 4;
            // 
            // passwordTxtbox
            // 
            passwordTxtbox.Location = new Point(93, 97);
            passwordTxtbox.Name = "passwordTxtbox";
            passwordTxtbox.Size = new Size(125, 27);
            passwordTxtbox.TabIndex = 5;
            passwordTxtbox.UseSystemPasswordChar = true;
            // 
            // showpasswordCheckbox
            // 
            showpasswordCheckbox.AutoSize = true;
            showpasswordCheckbox.BackColor = Color.Transparent;
            showpasswordCheckbox.Cursor = Cursors.Hand;
            showpasswordCheckbox.FlatStyle = FlatStyle.Flat;
            showpasswordCheckbox.Location = new Point(93, 130);
            showpasswordCheckbox.Name = "showpasswordCheckbox";
            showpasswordCheckbox.Size = new Size(128, 24);
            showpasswordCheckbox.TabIndex = 23;
            showpasswordCheckbox.Text = "Show Password";
            showpasswordCheckbox.UseVisualStyleBackColor = false;
            showpasswordCheckbox.CheckedChanged += showpasswordCheckbox_CheckedChanged;
            // 
            // LoginForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.vector_flat_medical_health_logo_template_692536_286;
            ClientSize = new Size(627, 411);
            Controls.Add(showpasswordCheckbox);
            Controls.Add(passwordTxtbox);
            Controls.Add(usernameTxtbox);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(backBtn);
            Controls.Add(loginBtn);
            Name = "LoginForm";
            Text = "LoginForm";
            Load += LoginForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button loginBtn;
        private Button backBtn;
        private Label label1;
        private Label label2;
        private TextBox usernameTxtbox;
        private TextBox passwordTxtbox;
        private CheckBox showpasswordCheckbox;
    }
}