﻿namespace FileOrgProject
{
    partial class LoginSignupForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            loginBtn = new Button();
            signupBtn = new Button();
            SuspendLayout();
            // 
            // loginBtn
            // 
            loginBtn.BackColor = Color.Honeydew;
            loginBtn.Location = new Point(159, 345);
            loginBtn.Name = "loginBtn";
            loginBtn.Size = new Size(94, 29);
            loginBtn.TabIndex = 0;
            loginBtn.Text = "Log in";
            loginBtn.UseVisualStyleBackColor = false;
            loginBtn.Click += loginBtn_Click;
            // 
            // signupBtn
            // 
            signupBtn.BackColor = Color.Honeydew;
            signupBtn.BackgroundImageLayout = ImageLayout.Stretch;
            signupBtn.Location = new Point(401, 345);
            signupBtn.Name = "signupBtn";
            signupBtn.Size = new Size(94, 29);
            signupBtn.TabIndex = 1;
            signupBtn.Text = "Sign up";
            signupBtn.UseVisualStyleBackColor = false;
            signupBtn.Click += signupBtn_Click;
            // 
            // LoginSignupForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.vector_flat_medical_health_logo_template_692536_286;
            ClientSize = new Size(625, 429);
            Controls.Add(signupBtn);
            Controls.Add(loginBtn);
            Name = "LoginSignupForm";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button loginBtn;
        private Button signupBtn;
    }
}
