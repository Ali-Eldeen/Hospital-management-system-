﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileOrgProject
{
    public partial class DeleteForm : Form
    {
        public DeleteForm()
        {
            InitializeComponent();
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            int searchId;   
            if (int.TryParse(IDtextBox.Text, out searchId))
            {
                DeleteRecord(searchId);
            }
            else
            {
                MessageBox.Show("Please enter a valid ID.");
            }
        }
        private void DeleteRecord(int searchId)
        {
            string tempFile = Path.GetTempFileName();

            using (BinaryReader br = new BinaryReader(File.Open(Program.filename, FileMode.Open, FileAccess.Read)))
            using (BinaryWriter bw = new BinaryWriter(File.Open(tempFile, FileMode.Create, FileAccess.Write)))
            {
                bool found = false;

                while (br.BaseStream.Position < br.BaseStream.Length)
                {
                    int id = br.ReadInt32();
                    if (id == searchId)
                    {
                        
                        found = true;
                        // Skip the remaining fields of the record
                        br.BaseStream.Seek(Program.rec_size - sizeof(int), SeekOrigin.Current);
                    }
                    else
                    {
                        // Write the record as is
                        bw.Write(id);
                        bw.Write(br.ReadBytes(Program.rec_size - sizeof(int)));
                    }
                }

                if (!found)
                {
                    MessageBox.Show("Record with ID " + searchId + " not found.");
                }
                else
                    MessageBox.Show("Record with ID " + searchId + " has been deleted successfully.");
            }

            // Replace the original file with the updated one
            File.Delete(Program.filename);
            File.Move(tempFile, Program.filename);
        }
        private void DeleteForm_Load(object sender, EventArgs e)
        {
            filenameTxtbox.Text = Program.filename;
            NumOfRecLabel.Text = (Program.file_size / Program.rec_size).ToString();
            FileSizeLabel.Text = Program.file_size.ToString();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new MainForm().Show();
        }
    }
}
