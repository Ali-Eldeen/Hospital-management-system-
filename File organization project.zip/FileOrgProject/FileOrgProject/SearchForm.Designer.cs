﻿namespace FileOrgProject
{
    partial class SearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BackBtn = new Button();
            searchBtn = new Button();
            FileSizeLabel = new Label();
            label9 = new Label();
            NumOfRecLabel = new Label();
            label7 = new Label();
            GendertextBox = new TextBox();
            YeartextBox = new TextBox();
            TeltextBox = new TextBox();
            NametextBox = new TextBox();
            IDtextBox = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            filenameTxtbox = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // BackBtn
            // 
            BackBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BackBtn.Location = new Point(12, 447);
            BackBtn.Name = "BackBtn";
            BackBtn.Size = new Size(89, 49);
            BackBtn.TabIndex = 59;
            BackBtn.Text = "Back";
            BackBtn.UseVisualStyleBackColor = true;
            BackBtn.Click += BackBtn_Click;
            // 
            // searchBtn
            // 
            searchBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            searchBtn.Location = new Point(460, 447);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(89, 49);
            searchBtn.TabIndex = 58;
            searchBtn.Text = "Search";
            searchBtn.UseVisualStyleBackColor = true;
            searchBtn.Click += searchBtn_Click;
            // 
            // FileSizeLabel
            // 
            FileSizeLabel.AutoSize = true;
            FileSizeLabel.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            FileSizeLabel.Location = new Point(628, 77);
            FileSizeLabel.Name = "FileSizeLabel";
            FileSizeLabel.Size = new Size(42, 27);
            FileSizeLabel.TabIndex = 57;
            FileSizeLabel.Text = ".....";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label9.Location = new Point(511, 77);
            label9.Name = "label9";
            label9.Size = new Size(94, 27);
            label9.TabIndex = 56;
            label9.Text = "File Size";
            // 
            // NumOfRecLabel
            // 
            NumOfRecLabel.AutoSize = true;
            NumOfRecLabel.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            NumOfRecLabel.Location = new Point(628, 38);
            NumOfRecLabel.Name = "NumOfRecLabel";
            NumOfRecLabel.Size = new Size(42, 27);
            NumOfRecLabel.TabIndex = 55;
            NumOfRecLabel.Text = ".....";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.Location = new Point(506, 38);
            label7.Name = "label7";
            label7.Size = new Size(99, 27);
            label7.TabIndex = 54;
            label7.Text = "#Records";
            // 
            // GendertextBox
            // 
            GendertextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            GendertextBox.Location = new Point(150, 325);
            GendertextBox.Name = "GendertextBox";
            GendertextBox.Size = new Size(331, 33);
            GendertextBox.TabIndex = 53;
            // 
            // YeartextBox
            // 
            YeartextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            YeartextBox.Location = new Point(150, 277);
            YeartextBox.Name = "YeartextBox";
            YeartextBox.Size = new Size(331, 33);
            YeartextBox.TabIndex = 52;
            // 
            // TeltextBox
            // 
            TeltextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            TeltextBox.Location = new Point(150, 228);
            TeltextBox.Name = "TeltextBox";
            TeltextBox.Size = new Size(331, 33);
            TeltextBox.TabIndex = 51;
            // 
            // NametextBox
            // 
            NametextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            NametextBox.Location = new Point(150, 175);
            NametextBox.Name = "NametextBox";
            NametextBox.Size = new Size(331, 33);
            NametextBox.TabIndex = 50;
            // 
            // IDtextBox
            // 
            IDtextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            IDtextBox.Location = new Point(150, 120);
            IDtextBox.Name = "IDtextBox";
            IDtextBox.Size = new Size(331, 33);
            IDtextBox.TabIndex = 49;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(24, 333);
            label6.Name = "label6";
            label6.Size = new Size(76, 27);
            label6.TabIndex = 48;
            label6.Text = "Gender";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = SystemColors.ActiveCaptionText;
            label5.Location = new Point(24, 280);
            label5.Name = "label5";
            label5.Size = new Size(54, 27);
            label5.TabIndex = 47;
            label5.Text = "Year";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(24, 231);
            label4.Name = "label4";
            label4.Size = new Size(41, 27);
            label4.TabIndex = 46;
            label4.Text = "Tel";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(24, 178);
            label3.Name = "label3";
            label3.Size = new Size(64, 27);
            label3.TabIndex = 45;
            label3.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(24, 123);
            label2.Name = "label2";
            label2.Size = new Size(39, 27);
            label2.TabIndex = 44;
            label2.Text = "ID";
            // 
            // filenameTxtbox
            // 
            filenameTxtbox.Enabled = false;
            filenameTxtbox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            filenameTxtbox.Location = new Point(150, 35);
            filenameTxtbox.Name = "filenameTxtbox";
            filenameTxtbox.Size = new Size(241, 33);
            filenameTxtbox.TabIndex = 43;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(24, 38);
            label1.Name = "label1";
            label1.Size = new Size(107, 27);
            label1.TabIndex = 42;
            label1.Text = "File Name";
            // 
            // SearchForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.image_from_rawpixel_id_2298455_jpeg_1596869142692;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(679, 508);
            Controls.Add(BackBtn);
            Controls.Add(searchBtn);
            Controls.Add(FileSizeLabel);
            Controls.Add(label9);
            Controls.Add(NumOfRecLabel);
            Controls.Add(label7);
            Controls.Add(GendertextBox);
            Controls.Add(YeartextBox);
            Controls.Add(TeltextBox);
            Controls.Add(NametextBox);
            Controls.Add(IDtextBox);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(filenameTxtbox);
            Controls.Add(label1);
            Name = "SearchForm";
            Text = "SearchForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button BackBtn;
        private Button searchBtn;
        private Label FileSizeLabel;
        private Label label9;
        private Label NumOfRecLabel;
        private Label label7;
        private TextBox GendertextBox;
        private TextBox YeartextBox;
        private TextBox TeltextBox;
        private TextBox NametextBox;
        private TextBox IDtextBox;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox filenameTxtbox;
        private Label label1;
    }
}