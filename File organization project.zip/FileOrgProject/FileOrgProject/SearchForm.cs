﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileOrgProject
{
    public partial class SearchForm : Form
    {
        public SearchForm()
        {
            InitializeComponent();
        }
        private void SearchForm_Load(object sender, EventArgs e)
        {
            {
                filenameTxtbox.Text = Program.filename;
                NumOfRecLabel.Text = (Program.file_size / Program.rec_size).ToString();
                FileSizeLabel.Text = Program.file_size.ToString();
            }
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }
        private void searchBtn_Click(object sender, EventArgs e)
        {
            int searchId;
            if (int.TryParse(IDtextBox.Text, out searchId))
            {
                BinaryReader br = new BinaryReader(File.Open(Program.filename, FileMode.Open, FileAccess.Read));
                bool found = false;

                while (br.BaseStream.Position < br.BaseStream.Length)
                {
                    int id = br.ReadInt32();
                    if (id == searchId)
                    {
                        NametextBox.Text = br.ReadString(); // Read Name 
                        TeltextBox.Text = br.ReadString(); // Read Tel
                        YeartextBox.Text = br.ReadInt32().ToString(); // Read Year
                        GendertextBox.Text = br.ReadString(); // Read Gender
                        found = true;
                        break;
                    }
                    else
                    {
                        // Move the stream position to the start of the next record
                        br.BaseStream.Seek(Program.rec_size - sizeof(int), SeekOrigin.Current);
                    }
                }

                br.Close();

                if (!found)
                {
                    MessageBox.Show("Record with ID " + searchId + " not found.");
                    // Clear text boxes if record not found
                    NametextBox.Clear();
                    TeltextBox.Clear();
                    YeartextBox.Clear();
                    GendertextBox.Clear();
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid ID.");
            }
        }
        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new MainForm().Show();
        }
    }
}