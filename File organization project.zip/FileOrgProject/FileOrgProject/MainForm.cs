﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml.Linq;

namespace FileOrgProject
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }
        private void openBtn_Click(object sender, EventArgs e)
        {
            Program.filename = "D:\\" + filenameTxtbox.Text + ".txt";
            if (!File.Exists(Program.filename))
            {
                existsLabel.Visible = true;
                yesBtn.Visible = true;
                noBtn.Visible = true;
            }
            else
            {
                Program.filename = "D:\\" + filenameTxtbox.Text + ".txt";
                MessageBox.Show("Please select what do you want to do from the toolbar.");

            }

        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            Program.filename = "D:\\" + filenameTxtbox.Text + ".txt";
            if (!File.Exists(Program.filename))
            {
                MessageBox.Show("File Does'nt exist please make sure of the file name", "Note", MessageBoxButtons.OK, MessageBoxIcon.Information);
                filenameTxtbox.Clear();
            }
            else
            {
                File.Delete(Program.filename);
                MessageBox.Show("File is Deleted ");
                filenameTxtbox.Clear();
                existsLabel.Visible = false;
            }

        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            deleteBtn.Visible = true;
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            openBtn.Visible = true;
        }

        private void addNewStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new InsertForm().Show();
        }

        private void viewExistingStudentsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new DisplayForm().Show();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void noBtn_Click(object sender, EventArgs e)
        {
            filenameTxtbox.Clear();
            existsLabel.Visible = false;
            yesBtn.Visible = false;
            noBtn.Visible = false;
        }

        private void yesBtn_Click(object sender, EventArgs e)
        {
            existsLabel.Visible = false;
            yesBtn.Visible = false;
            noBtn.Visible = false;


            File.Create(Program.filename).Close();
            MessageBox.Show("File is Created Successfully\n" +
                "Please select what do you want to do from the toolbar.", "Note",
           MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void signupBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LoginSignupForm().Show();
        }

        private void searchForStudentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new SearchForm().Show();
        }

        private void updatePatientInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new UpdateForm().Show();
        }

        private void deletePatientInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            new DeleteForm().Show();
        }
    }
}
