﻿
namespace FileOrgProject
{
    partial class SignupForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            usernameTxtbox = new TextBox();
            nameTxtbox = new TextBox();
            label2 = new Label();
            label1 = new Label();
            backBtn = new Button();
            signupBtn = new Button();
            confirmpasswordTxtbox = new TextBox();
            passwordTxtbox = new TextBox();
            label3 = new Label();
            label4 = new Label();
            showpasswordCheckbox = new CheckBox();
            SuspendLayout();
            // 
            // usernameTxtbox
            // 
            usernameTxtbox.Location = new Point(139, 65);
            usernameTxtbox.Name = "usernameTxtbox";
            usernameTxtbox.Size = new Size(125, 27);
            usernameTxtbox.TabIndex = 11;
            // 
            // nameTxtbox
            // 
            nameTxtbox.Location = new Point(139, 12);
            nameTxtbox.Name = "nameTxtbox";
            nameTxtbox.Size = new Size(125, 27);
            nameTxtbox.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Location = new Point(4, 12);
            label2.Name = "label2";
            label2.Size = new Size(49, 20);
            label2.TabIndex = 9;
            label2.Text = "Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Location = new Point(4, 69);
            label1.Name = "label1";
            label1.Size = new Size(75, 20);
            label1.TabIndex = 8;
            label1.Text = "Username";
            // 
            // backBtn
            // 
            backBtn.BackColor = Color.Honeydew;
            backBtn.Location = new Point(12, 385);
            backBtn.Name = "backBtn";
            backBtn.Size = new Size(94, 29);
            backBtn.TabIndex = 7;
            backBtn.Text = "Back";
            backBtn.UseVisualStyleBackColor = false;
            backBtn.Click += backBtn_Click;
            // 
            // signupBtn
            // 
            signupBtn.BackColor = Color.Honeydew;
            signupBtn.Location = new Point(263, 313);
            signupBtn.Name = "signupBtn";
            signupBtn.Size = new Size(94, 29);
            signupBtn.TabIndex = 6;
            signupBtn.Text = "Sign up";
            signupBtn.UseVisualStyleBackColor = false;
            signupBtn.Click += signupBtn_Click;
            // 
            // confirmpasswordTxtbox
            // 
            confirmpasswordTxtbox.Location = new Point(139, 172);
            confirmpasswordTxtbox.Name = "confirmpasswordTxtbox";
            confirmpasswordTxtbox.Size = new Size(125, 27);
            confirmpasswordTxtbox.TabIndex = 15;
            confirmpasswordTxtbox.UseSystemPasswordChar = true;
            // 
            // passwordTxtbox
            // 
            passwordTxtbox.Location = new Point(139, 118);
            passwordTxtbox.Name = "passwordTxtbox";
            passwordTxtbox.Size = new Size(125, 27);
            passwordTxtbox.TabIndex = 14;
            passwordTxtbox.UseSystemPasswordChar = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Location = new Point(4, 118);
            label3.Name = "label3";
            label3.Size = new Size(70, 20);
            label3.TabIndex = 13;
            label3.Text = "Password";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Location = new Point(4, 175);
            label4.Name = "label4";
            label4.Size = new Size(129, 20);
            label4.TabIndex = 12;
            label4.Text = "Confirm password";
            label4.Click += label4_Click;
            // 
            // showpasswordCheckbox
            // 
            showpasswordCheckbox.AutoSize = true;
            showpasswordCheckbox.BackColor = Color.Transparent;
            showpasswordCheckbox.Cursor = Cursors.Hand;
            showpasswordCheckbox.FlatStyle = FlatStyle.Flat;
            showpasswordCheckbox.Location = new Point(141, 145);
            showpasswordCheckbox.Name = "showpasswordCheckbox";
            showpasswordCheckbox.Size = new Size(128, 24);
            showpasswordCheckbox.TabIndex = 22;
            showpasswordCheckbox.Text = "Show Password";
            showpasswordCheckbox.UseVisualStyleBackColor = false;
            showpasswordCheckbox.CheckedChanged += showpasswordCheckbox_CheckedChanged;
            // 
            // SignupForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            BackgroundImage = Properties.Resources.vector_flat_medical_health_logo_template_692536_286;
            ClientSize = new Size(622, 426);
            Controls.Add(showpasswordCheckbox);
            Controls.Add(confirmpasswordTxtbox);
            Controls.Add(passwordTxtbox);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(usernameTxtbox);
            Controls.Add(nameTxtbox);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(backBtn);
            Controls.Add(signupBtn);
            Name = "SignupForm";
            Text = "SignupForm";
            Load += SignupForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private TextBox usernameTxtbox;
        private TextBox nameTxtbox;
        private Label label2;
        private Label label1;
        private Button backBtn;
        private Button signupBtn;
        private TextBox confirmpasswordTxtbox;
        private TextBox passwordTxtbox;
        private Label label3;
        private Label label4;
        private CheckBox showpasswordCheckbox;
    }

}