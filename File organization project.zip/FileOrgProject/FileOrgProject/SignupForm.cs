﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace FileOrgProject
{
    public partial class SignupForm : Form
    {
        public SignupForm()
        {
            InitializeComponent();
        }
        private const string PasswordsFile = "D:\\passwords.txt";
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }
        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LoginSignupForm().Show();
        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }
        private void signupBtn_Click(object sender, EventArgs e)
        {
            if (passwordTxtbox.Text == confirmpasswordTxtbox.Text)
            {
                string username = usernameTxtbox.Text;
                string password = passwordTxtbox.Text;

                if (string.IsNullOrWhiteSpace(nameTxtbox.Text) ||
                   string.IsNullOrWhiteSpace(usernameTxtbox.Text) ||
                   string.IsNullOrWhiteSpace(passwordTxtbox.Text) ||
                   string.IsNullOrWhiteSpace(confirmpasswordTxtbox.Text))
                {
                    MessageBox.Show("Please fill in all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                string hashedPassword = HashPassword(password);

                string credentials = string.Format("{0},{1}", username, hashedPassword);
                File.AppendAllText(PasswordsFile, credentials + Environment.NewLine);
                this.Hide();
                new LoginForm().Show();
            }
            else
            {
                MessageBox.Show("Passwords is not the same");
            }
        }

        private void SignupForm_Load(object sender, EventArgs e)
        {

        }

        private void showpasswordCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (showpasswordCheckbox.Checked)
            {
                passwordTxtbox.UseSystemPasswordChar = false;
                confirmpasswordTxtbox.UseSystemPasswordChar = false;
            }
            else
            {
                passwordTxtbox.UseSystemPasswordChar = true;
                confirmpasswordTxtbox.UseSystemPasswordChar = true;
            }
        }
    }
}
