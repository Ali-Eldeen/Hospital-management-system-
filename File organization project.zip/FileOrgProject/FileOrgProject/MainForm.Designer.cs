﻿namespace FileOrgProject
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            filenameTxtbox = new TextBox();
            openBtn = new Button();
            deleteBtn = new Button();
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            deleteToolStripMenuItem = new ToolStripMenuItem();
            exitToolStripMenuItem = new ToolStripMenuItem();
            studentsToolStripMenuItem = new ToolStripMenuItem();
            addNewStudentToolStripMenuItem = new ToolStripMenuItem();
            viewExistingStudentsToolStripMenuItem = new ToolStripMenuItem();
            searchForStudentToolStripMenuItem = new ToolStripMenuItem();
            updatePatientInfoToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            label2 = new Label();
            existsLabel = new Label();
            noBtn = new Button();
            yesBtn = new Button();
            signupBtn = new Button();
            deletePatientInfoToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(62, 154);
            label1.Name = "label1";
            label1.Size = new Size(107, 27);
            label1.TabIndex = 0;
            label1.Text = "File Name";
            // 
            // filenameTxtbox
            // 
            filenameTxtbox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            filenameTxtbox.Location = new Point(67, 193);
            filenameTxtbox.Margin = new Padding(3, 4, 3, 4);
            filenameTxtbox.Name = "filenameTxtbox";
            filenameTxtbox.Size = new Size(366, 33);
            filenameTxtbox.TabIndex = 1;
            // 
            // openBtn
            // 
            openBtn.BackColor = SystemColors.ControlLightLight;
            openBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            openBtn.Location = new Point(129, 245);
            openBtn.Margin = new Padding(3, 4, 3, 4);
            openBtn.Name = "openBtn";
            openBtn.Size = new Size(107, 58);
            openBtn.TabIndex = 2;
            openBtn.Text = "Open";
            openBtn.UseVisualStyleBackColor = false;
            openBtn.Click += openBtn_Click;
            // 
            // deleteBtn
            // 
            deleteBtn.BackColor = SystemColors.ControlLightLight;
            deleteBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            deleteBtn.Location = new Point(260, 245);
            deleteBtn.Margin = new Padding(3, 4, 3, 4);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(107, 58);
            deleteBtn.TabIndex = 3;
            deleteBtn.Text = "Delete";
            deleteBtn.UseVisualStyleBackColor = false;
            deleteBtn.Visible = false;
            deleteBtn.Click += DeleteBtn_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, studentsToolStripMenuItem, helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(801, 28);
            menuStrip1.TabIndex = 9;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { deleteToolStripMenuItem, exitToolStripMenuItem });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(46, 24);
            fileToolStripMenuItem.Text = "File";
            // 
            // deleteToolStripMenuItem
            // 
            deleteToolStripMenuItem.Image = Properties.Resources.removeIcon;
            deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            deleteToolStripMenuItem.Size = new Size(224, 26);
            deleteToolStripMenuItem.Text = "Delete";
            deleteToolStripMenuItem.Click += deleteToolStripMenuItem_Click;
            // 
            // exitToolStripMenuItem
            // 
            exitToolStripMenuItem.Image = Properties.Resources.exittIcon;
            exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            exitToolStripMenuItem.Size = new Size(224, 26);
            exitToolStripMenuItem.Text = "Exit";
            exitToolStripMenuItem.Click += exitToolStripMenuItem_Click;
            // 
            // studentsToolStripMenuItem
            // 
            studentsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { addNewStudentToolStripMenuItem, viewExistingStudentsToolStripMenuItem, searchForStudentToolStripMenuItem, deletePatientInfoToolStripMenuItem, updatePatientInfoToolStripMenuItem });
            studentsToolStripMenuItem.Name = "studentsToolStripMenuItem";
            studentsToolStripMenuItem.Size = new Size(74, 24);
            studentsToolStripMenuItem.Text = "Patients";
            // 
            // addNewStudentToolStripMenuItem
            // 
            addNewStudentToolStripMenuItem.Image = Properties.Resources.addIcon;
            addNewStudentToolStripMenuItem.Name = "addNewStudentToolStripMenuItem";
            addNewStudentToolStripMenuItem.Size = new Size(224, 26);
            addNewStudentToolStripMenuItem.Text = "Add new patients";
            addNewStudentToolStripMenuItem.Click += addNewStudentToolStripMenuItem_Click;
            // 
            // viewExistingStudentsToolStripMenuItem
            // 
            viewExistingStudentsToolStripMenuItem.Image = Properties.Resources.openIcon;
            viewExistingStudentsToolStripMenuItem.Name = "viewExistingStudentsToolStripMenuItem";
            viewExistingStudentsToolStripMenuItem.Size = new Size(224, 26);
            viewExistingStudentsToolStripMenuItem.Text = "View all patients";
            viewExistingStudentsToolStripMenuItem.Click += viewExistingStudentsToolStripMenuItem_Click;
            // 
            // searchForStudentToolStripMenuItem
            // 
            searchForStudentToolStripMenuItem.Image = Properties.Resources.searchIcon;
            searchForStudentToolStripMenuItem.Name = "searchForStudentToolStripMenuItem";
            searchForStudentToolStripMenuItem.Size = new Size(224, 26);
            searchForStudentToolStripMenuItem.Text = "Search for patients";
            searchForStudentToolStripMenuItem.Click += searchForStudentToolStripMenuItem_Click;
            // 
            // updatePatientInfoToolStripMenuItem
            // 
            updatePatientInfoToolStripMenuItem.Image = Properties.Resources.copyIcon;
            updatePatientInfoToolStripMenuItem.Name = "updatePatientInfoToolStripMenuItem";
            updatePatientInfoToolStripMenuItem.Size = new Size(224, 26);
            updatePatientInfoToolStripMenuItem.Text = "Update patient info";
            updatePatientInfoToolStripMenuItem.Click += updatePatientInfoToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.Image = Properties.Resources.helpIcon;
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(75, 24);
            helpToolStripMenuItem.Text = "Help";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Monotype Corsiva", 22.2F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(259, 72);
            label2.Name = "label2";
            label2.Size = new Size(209, 45);
            label2.TabIndex = 10;
            label2.Text = "Hospital App";
            // 
            // existsLabel
            // 
            existsLabel.AutoSize = true;
            existsLabel.BackColor = Color.Transparent;
            existsLabel.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            existsLabel.ForeColor = SystemColors.ActiveCaptionText;
            existsLabel.Location = new Point(3, 334);
            existsLabel.Name = "existsLabel";
            existsLabel.Size = new Size(551, 27);
            existsLabel.TabIndex = 11;
            existsLabel.Text = "File already doesn't exist do you want to create a new one?";
            existsLabel.Visible = false;
            // 
            // noBtn
            // 
            noBtn.BackColor = SystemColors.ControlLightLight;
            noBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            noBtn.Location = new Point(260, 393);
            noBtn.Margin = new Padding(3, 4, 3, 4);
            noBtn.Name = "noBtn";
            noBtn.Size = new Size(107, 58);
            noBtn.TabIndex = 13;
            noBtn.Text = "No";
            noBtn.UseVisualStyleBackColor = false;
            noBtn.Visible = false;
            noBtn.Click += noBtn_Click;
            // 
            // yesBtn
            // 
            yesBtn.BackColor = SystemColors.ControlLightLight;
            yesBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            yesBtn.Location = new Point(129, 393);
            yesBtn.Margin = new Padding(3, 4, 3, 4);
            yesBtn.Name = "yesBtn";
            yesBtn.Size = new Size(107, 58);
            yesBtn.TabIndex = 12;
            yesBtn.Text = "Yes";
            yesBtn.UseVisualStyleBackColor = false;
            yesBtn.Visible = false;
            yesBtn.Click += yesBtn_Click;
            // 
            // signupBtn
            // 
            signupBtn.BackColor = SystemColors.ControlLightLight;
            signupBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            signupBtn.Location = new Point(12, 547);
            signupBtn.Margin = new Padding(3, 4, 3, 4);
            signupBtn.Name = "signupBtn";
            signupBtn.Size = new Size(107, 58);
            signupBtn.TabIndex = 14;
            signupBtn.Text = "Sign out";
            signupBtn.UseVisualStyleBackColor = false;
            signupBtn.Visible = false;
            signupBtn.Click += signupBtn_Click;
            // 
            // deletePatientInfoToolStripMenuItem
            // 
            deletePatientInfoToolStripMenuItem.Image = Properties.Resources.removeIcon;
            deletePatientInfoToolStripMenuItem.Name = "deletePatientInfoToolStripMenuItem";
            deletePatientInfoToolStripMenuItem.Size = new Size(224, 26);
            deletePatientInfoToolStripMenuItem.Text = "Delete patient info";
            deletePatientInfoToolStripMenuItem.Click += deletePatientInfoToolStripMenuItem_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.image_from_rawpixel_id_2298455_jpeg_1596869142692;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(801, 618);
            Controls.Add(signupBtn);
            Controls.Add(noBtn);
            Controls.Add(yesBtn);
            Controls.Add(existsLabel);
            Controls.Add(label2);
            Controls.Add(deleteBtn);
            Controls.Add(openBtn);
            Controls.Add(filenameTxtbox);
            Controls.Add(label1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Margin = new Padding(3, 4, 3, 4);
            Name = "MainForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Modern Academy App";
            Load += MainForm_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox filenameTxtbox;
        private System.Windows.Forms.Button openBtn;
        private System.Windows.Forms.Button deleteBtn;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewExistingStudentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchForStudentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private Label existsLabel;
        private Button noBtn;
        private Button yesBtn;
        private Button signupBtn;
        private ToolStripMenuItem updatePatientInfoToolStripMenuItem;
        private ToolStripMenuItem deletePatientInfoToolStripMenuItem;
    }
}
