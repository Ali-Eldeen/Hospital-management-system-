﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace FileOrgProject
{
    public partial class InsertForm : Form
    {
        public InsertForm()
        {
            InitializeComponent();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }
        private void InsertForm_Load(object sender, EventArgs e)
        {
            {
                filenameTxtbox.Text = Program.filename;
                NumOfRecLabel.Text = (Program.file_size / Program.rec_size).ToString();
                FileSizeLabel.Text = Program.file_size.ToString();
            }
        }

        private void SaveBtn_Click(object sender, EventArgs e)
        {
            BinaryWriter bw = new BinaryWriter(File.Open(Program.filename,
            FileMode.Open, FileAccess.Write));
            int length = (int)bw.BaseStream.Length;
            if (length != 0)
            {
                bw.BaseStream.Seek(length, SeekOrigin.Begin);
            }
            bw.Write(int.Parse(IDtextBox.Text));
            NametextBox.Text = NametextBox.Text.PadRight(10);
            bw.Write(NametextBox.Text.Substring(0, 10));
            TeltextBox.Text = TeltextBox.Text.PadRight(11);
            bw.Write(TeltextBox.Text.Substring(0, 11));
            bw.Write(int.Parse(YeartextBox.Text));
            bw.Write(GendertextBox.Text.Substring(0, 1));
            length += Program.rec_size;
            IDtextBox.Clear(); NametextBox.Clear(); TeltextBox.Clear();
            YeartextBox.Clear(); GendertextBox.Clear();
            NumOfRecLabel.Text = (length / Program.rec_size).ToString();
            Program.file_size = length;
            FileSizeLabel.Text = length.ToString();
            MessageBox.Show(" Data is Saved Successfully ");
            bw.Close();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new MainForm().Show();
        }

        private void InsertForm_Load_1(object sender, EventArgs e)
        {

        }
    }

}
