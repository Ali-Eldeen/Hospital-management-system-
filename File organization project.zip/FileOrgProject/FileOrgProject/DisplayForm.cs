﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileOrgProject
{
    public partial class DisplayForm : Form
    {
        public DisplayForm()
        {
            InitializeComponent();
        }
        private void DisplayForm_Load(object sender, EventArgs e)
        {
            {
                filenameTxtbox.Text = Program.filename;
                NumOfRecLabel.Text = (Program.file_size / Program.rec_size).ToString();
                FileSizeLabel.Text = Program.file_size.ToString();
            }
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }




        private void displayBtn_Click(object sender, EventArgs e)
        {
            BinaryReader br = new BinaryReader(File.Open(Program.filename,
            FileMode.Open, FileAccess.Read));
            int num_of_records = (int)br.BaseStream.Length / Program.rec_size;
            if (num_of_records > 0)
            {
                displayBtn.Text = "Next";
                br.BaseStream.Seek(Program.count, SeekOrigin.Begin);
                IDtextBox.Text = br.ReadInt32().ToString();
                NametextBox.Text = br.ReadString(); // Read Name 
                TeltextBox.Text = br.ReadString(); // Read Tel
                YeartextBox.Text = br.ReadInt32().ToString(); // Read Year
                GendertextBox.Text = br.ReadString(); // Read Gender
                NumOfRecLabel.Text = num_of_records.ToString();
                FileSizeLabel.Text = br.BaseStream.Length.ToString();
               
                if ((Program.count / Program.rec_size) >= (num_of_records - 1))
                    Program.count = 0;
                else
                    Program.count += Program.rec_size;
            }
            else MessageBox.Show("Empty File");
            br.Close();
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new MainForm().Show();
        }
    }
}
