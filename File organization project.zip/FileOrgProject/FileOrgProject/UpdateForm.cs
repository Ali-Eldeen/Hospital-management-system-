﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FileOrgProject
{
    public partial class UpdateForm : Form
    {
        public UpdateForm()
        {
            InitializeComponent();
        }

        private void UpdateForm_Load(object sender, EventArgs e)
        {
            filenameTxtbox.Text = Program.filename;
            NumOfRecLabel.Text = (Program.file_size / Program.rec_size).ToString();
            FileSizeLabel.Text = Program.file_size.ToString();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }
        private void updateBtn_Click(object sender, EventArgs e)
        {
            int searchId;
            if (int.TryParse(IDtextBox.Text, out searchId))
            {
                UpdateRecord(searchId, NametextBox.Text, TeltextBox.Text, int.Parse(YeartextBox.Text), GendertextBox.Text);
            }
            else
            {
                MessageBox.Show("Please enter a valid ID.");
            }
        }
        private void UpdateRecord(int searchId, string newName, string newTel, int newYear, string newGender)
        {
            string tempFile = Path.GetTempFileName();

            using (BinaryReader br = new BinaryReader(File.Open(Program.filename, FileMode.Open, FileAccess.Read)))
            using (BinaryWriter bw = new BinaryWriter(File.Open(tempFile, FileMode.Create, FileAccess.Write)))
            {
                bool found = false;

                while (br.BaseStream.Position < br.BaseStream.Length)
                {
                    int id = br.ReadInt32();
                    if (id == searchId)
                    {
                        bw.Write(searchId);
                        bw.Write(newName.PadRight(10).Substring(0, 10));
                        bw.Write(newTel.PadRight(11).Substring(0, 11));
                        bw.Write(newYear);
                        bw.Write(newGender.Substring(0, 1));
                        found = true;
                        // Skip the remaining fields of the record
                        br.BaseStream.Seek(Program.rec_size - sizeof(int), SeekOrigin.Current);
                    }
                    else
                    {
                        // Write the record as is
                        bw.Write(id);
                        bw.Write(br.ReadBytes(Program.rec_size - sizeof(int)));
                    }
                }

                if (!found)
                {
                    MessageBox.Show("Record with ID " + searchId + " not found.");
                }
                else
                    MessageBox.Show("Record with ID " + searchId + " has been updated successfully.");

            }

            // Replace the original file with the updated one
            File.Delete(Program.filename);
            File.Move(tempFile, Program.filename);
        }



        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new MainForm().Show();
        }
    }
}
