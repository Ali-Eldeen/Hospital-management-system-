﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using static System.Windows.Forms.DataFormats;

namespace FileOrgProject
{
    public partial class LoginForm : Form
    {

        public LoginForm()
        {
            InitializeComponent();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }
        private const string PasswordsFile = "D:\\passwords.txt";

        private void LoginForm_Load(object sender, EventArgs e)
        {

        }
        private string HashPassword(string password)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                foreach (byte b in bytes)
                {
                    builder.Append(b.ToString("x2"));
                }
                return builder.ToString();
            }
        }
        private bool CheckCredentials(string id, string hashedPassword)
        {
            // قراءة بيانات المستخدم من الملف
            string[] lines = File.ReadAllLines(PasswordsFile);

            foreach (string line in lines)
            {
                string[] fields = line.Split(',');
                if (fields.Length == 2 && fields[0] == id && fields[1] == hashedPassword)
                {
                    return true;
                }
            }

            return false;
        }
        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LoginSignupForm().Show();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            string username = usernameTxtbox.Text;
            string password = passwordTxtbox.Text;

            string hashedPassword = HashPassword(password);
            if (CheckCredentials(username, hashedPassword))
            {
                this.Hide();
                new MainForm().Show();
            }
            else
            {
                MessageBox.Show("Wrong username or password.");
                usernameTxtbox.Clear();
                passwordTxtbox.Clear();
            }

        }

        private void showpasswordCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (showpasswordCheckbox.Checked)
                passwordTxtbox.UseSystemPasswordChar = false;
           
            else
                passwordTxtbox.UseSystemPasswordChar = true;
        }
    }
}
