namespace FileOrgProject
{
    public partial class LoginSignupForm : Form
    {
        public LoginSignupForm()
        {
            InitializeComponent();
        }
        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);

            if (e.CloseReason == CloseReason.WindowsShutDown) return;

            Application.Exit();
        }

        private void loginBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new LoginForm().Show();
        }
        private void signupBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            new SignupForm().Show();
        }
    }
}
