﻿namespace FileOrgProject
{
    partial class DeleteForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BackBtn = new Button();
            deleteBtn = new Button();
            FileSizeLabel = new Label();
            label9 = new Label();
            NumOfRecLabel = new Label();
            label7 = new Label();
            IDtextBox = new TextBox();
            label2 = new Label();
            filenameTxtbox = new TextBox();
            label1 = new Label();
            SuspendLayout();
            // 
            // BackBtn
            // 
            BackBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BackBtn.Location = new Point(80, 178);
            BackBtn.Name = "BackBtn";
            BackBtn.Size = new Size(89, 49);
            BackBtn.TabIndex = 36;
            BackBtn.Text = "Back";
            BackBtn.UseVisualStyleBackColor = true;
            BackBtn.Click += BackBtn_Click;
            // 
            // deleteBtn
            // 
            deleteBtn.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            deleteBtn.Location = new Point(528, 178);
            deleteBtn.Name = "deleteBtn";
            deleteBtn.Size = new Size(89, 49);
            deleteBtn.TabIndex = 35;
            deleteBtn.Text = "Delete";
            deleteBtn.UseVisualStyleBackColor = true;
            deleteBtn.Click += deleteBtn_Click;
            // 
            // FileSizeLabel
            // 
            FileSizeLabel.AutoSize = true;
            FileSizeLabel.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            FileSizeLabel.Location = new Point(690, 57);
            FileSizeLabel.Name = "FileSizeLabel";
            FileSizeLabel.Size = new Size(42, 27);
            FileSizeLabel.TabIndex = 34;
            FileSizeLabel.Text = ".....";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label9.Location = new Point(573, 57);
            label9.Name = "label9";
            label9.Size = new Size(94, 27);
            label9.TabIndex = 33;
            label9.Text = "File Size";
            // 
            // NumOfRecLabel
            // 
            NumOfRecLabel.AutoSize = true;
            NumOfRecLabel.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            NumOfRecLabel.Location = new Point(690, 18);
            NumOfRecLabel.Name = "NumOfRecLabel";
            NumOfRecLabel.Size = new Size(42, 27);
            NumOfRecLabel.TabIndex = 32;
            NumOfRecLabel.Text = ".....";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.Location = new Point(568, 18);
            label7.Name = "label7";
            label7.Size = new Size(99, 27);
            label7.TabIndex = 31;
            label7.Text = "#Records";
            // 
            // IDtextBox
            // 
            IDtextBox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            IDtextBox.Location = new Point(206, 107);
            IDtextBox.Name = "IDtextBox";
            IDtextBox.Size = new Size(331, 33);
            IDtextBox.TabIndex = 26;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(80, 110);
            label2.Name = "label2";
            label2.Size = new Size(39, 27);
            label2.TabIndex = 21;
            label2.Text = "ID";
            // 
            // filenameTxtbox
            // 
            filenameTxtbox.Enabled = false;
            filenameTxtbox.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            filenameTxtbox.Location = new Point(206, 22);
            filenameTxtbox.Name = "filenameTxtbox";
            filenameTxtbox.Size = new Size(241, 33);
            filenameTxtbox.TabIndex = 20;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Monotype Corsiva", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(80, 25);
            label1.Name = "label1";
            label1.Size = new Size(107, 27);
            label1.TabIndex = 19;
            label1.Text = "File Name";
            // 
            // DeleteForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.image_from_rawpixel_id_2298455_jpeg_1596869142692;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(746, 239);
            Controls.Add(BackBtn);
            Controls.Add(deleteBtn);
            Controls.Add(FileSizeLabel);
            Controls.Add(label9);
            Controls.Add(NumOfRecLabel);
            Controls.Add(label7);
            Controls.Add(IDtextBox);
            Controls.Add(label2);
            Controls.Add(filenameTxtbox);
            Controls.Add(label1);
            Name = "DeleteForm";
            Text = "DeleteForm";
            Load += DeleteForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button BackBtn;
        private Button deleteBtn;
        private Label FileSizeLabel;
        private Label label9;
        private Label NumOfRecLabel;
        private Label label7;
        private TextBox IDtextBox;
        private Label label2;
        private TextBox filenameTxtbox;
        private Label label1;
    }
}